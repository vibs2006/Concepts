﻿using System.Web.Mvc;

namespace Pluralsight.Owin.Demo.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
    }
}